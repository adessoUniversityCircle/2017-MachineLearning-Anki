process.env.BLUETOOTH_HCI_SOCKET_USB_PID = "0x8143";
process.env.BLUETOOTH_HCI_SOCKET_USB_VID = "0x413c";

var net = require('net');
var noble = require('noble');
var util = require('util');
var mqtt = require('mqtt');

var available = [];
var connected = [];
var last = "";

var client = mqtt.connect('mqtt://broker.mqttdashboard.com', { will: { topic: 'ble/discovery', payload: '[]', retain: true }});
client.on('connect', mqttConnected);
client.on('message', mqttMessageReceived);

noble.on('stateChange', (state) => {
  if (noble.state === 'poweredOn') {
    noble.scanner = setInterval(nobleScan, 15000)
    nobleScan();
  }
  else {
    noble.stopScanning();
    clearInterval(noble.scanner);
  }
});

noble.on('discover', (peripheral) => {
  available.push(peripheral.id);
  client.publish('ble/'+peripheral.id+'/localName', new Buffer(peripheral.advertisement.localName).toString('hex'));
  client.publish('ble/'+peripheral.id+'/manufacturerData', peripheral.advertisement.manufacturerData.toString('hex'));
});

function nobleScan() {
  available = [];
  noble.startScanning(['be15beef6186407e83810bd89c4d8df4']);
  setTimeout(() => {
    noble.stopScanning();
    var message = JSON.stringify(available.concat(connected).sort());
    if (message !== last) {
      client.publish('ble/discovery', message, { retain: true });
      last = message;
    }
  }, 1000);
}

function mqttConnected() {
  client.subscribe("ble/discovery/request");
}

function mqttMessageReceived(topic, message) {
  console.log(message);
}
