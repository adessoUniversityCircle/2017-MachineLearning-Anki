var net = require('net');
var noble = require('noble');
var util = require('util');

var server = net.createServer(function(client) {
  client.vehicles = [];
  client.protocol = "1.0";

  client.once("error", (err) => {
    console.log("connection error"); // client disconnected?
    client.vehicles.forEach((vehicle) => vehicle.disconnect());
  });
  client.on("data", function(data) {
    data.toString().split("\r\n").forEach(function(line) {
	  var command = line.toString().trim().split(";");
	  if (command[0])
	    true; //console.log(command)
	  switch(command[0])
	  {
            case "PROTOCOL":
              client.protocol = command[1];
              client.write("PROTOCOL;OK\n");
              break;
            case "CONNECTIONS":
              var conns = Object.keys(noble._peripherals).map(k => noble._peripherals[k]).filter(x => x.state == 'connected').length;
              client.write(util.format("CONNECTIONS;%s\n", conns));
              break;
	    case "SCAN":
	      if (noble.state === 'poweredOn') {
	        var discover = function(device) {
	          setTimeout( function() {
                    client.write(util.format("SCAN;%s;%s;%s\n",
	              device.id,
	              device.advertisement.manufacturerData.toString('hex'),
	              new Buffer(device.advertisement.localName).toString('hex')));
                  }, Math.floor(Math.random() * (2000 - 300) + 300));
	        };
	
	        noble.on('discover', discover);
	        noble.startScanning(['be15beef6186407e83810bd89c4d8df4']);
	
	        setTimeout(function() {
	           noble.stopScanning();
	           noble.removeListener('discover', discover)
	           client.write("SCAN;COMPLETED\n");
	        }, 3000);
	      }
	      else {
	        client.write("SCAN;ERROR\n");
	      }
	      break;
	      
	    case "CONNECT":
	      console.log("connect begin");
	      if (command.length != 2) {
	        client.write("CONNECT;ERROR\n");
	        break;
	      }
	
	      var vehicle = noble._peripherals[command[1]];
	      if (vehicle === undefined) {
	        client.write("CONNECT;ERROR\n");
	        break;
	      }
	
	      var success = false;
	
	      vehicle.connect(function(error) {
                console.log("connect error: " + util.inspect(error));
	        vehicle.discoverSomeServicesAndCharacteristics(
	            ["be15beef6186407e83810bd89c4d8df4"],
	            ["be15bee06186407e83810bd89c4d8df4", "be15bee16186407e83810bd89c4d8df4"],
	            function(error, services, characteristics) {
                      console.log("discoverServices error: " + util.inspect(error));
	              vehicle.reader = characteristics.find(x => !x.properties.includes("write"));
	              vehicle.writer = characteristics.find(x => x.properties.includes("write"));
	
	              vehicle.reader.notify(true);
                      vehicle.reader.removeAllListeners();
	              vehicle.reader.on('read', function(data, isNotification) {
                        var timestamp = Date.now();
                        if (client.protocol == "1.0") {
	                  client.write(util.format("%s;%s\n", vehicle.id, data.toString("hex")));
                        } else {
	                  client.write(util.format("%s;%s;%d\n", vehicle.id, data.toString("hex"), timestamp));
                        }
//	                console.log(util.format("> %s;%s", vehicle.id, data.toString("hex")));
	              });
	              client.write("CONNECT;SUCCESS\n");
                      client.vehicles.push(vehicle);
	              console.log("connect success");
	              success = true;
                      vehicle.once('disconnect', () => {
		        console.log('vehicle disconnected');
		      });

	            }
	        );
	      });
	
	      setTimeout(() => {
	        if (!success) {
	      	  client.write("CONNECT;ERROR\n");
                  vehicle.removeAllListeners();
	          console.log("connect error");
	        }
	      }, 500);
	
	      break;
	      
	    case "DISCONNECT":
	      if (command.length != 2) {
	        client.write("DISCONNECT;ERROR\n");
	        break;
	      }
	
	      var vehicle = noble._peripherals[command[1]];
	      if (vehicle === undefined) {
	        client.write("DISCONNECT;ERROR\n");
	        break;
	      }
	
	      vehicle.disconnect();
	      client.write("DISCONNECT;SUCCESS\n");
	      break;
	    
	    default:
	      if (command.length == 2 && noble._peripherals[command[0]] !== undefined) {
	        var vehicle = noble._peripherals[command[0]];
	        vehicle.writer.write(new Buffer(command[1], 'hex'));
//	        console.log(util.format("< %s;%s", vehicle.id, command[1]));     
	      }
	  }
	});
  });
});

server.listen(5000);

console.log("Server gestartet")
