package de.adesso.anki.roadmap;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreType;

import de.adesso.anki.roadpieces.Roadpiece;

@JsonIgnoreType
public class Section {
  private Roadpiece piece;
  
  private Position entry;
  
  protected Section() { }
  
  public Section(Roadpiece piece, Position entry, Position exit) {
    this.piece = piece;
    this.entry = entry;
    this.exit = exit;
  }
  
  @JsonIgnore
  public Section getPrev() {
    return prev;
  }

  public void setPrev(Section prev) {
    this.prev = prev;
  }

  @JsonIgnore
  public Section getNext() {
    return next;
  }

  public void setNext(Section next) {
    this.next = next;
  }

  public Roadpiece getPiece() {
    return piece;
  }

  public Position getEntry() {
    return entry;
  }

  public Position getExit() {
    return exit;
  }

  private Position exit;
  
  private Section prev;
  private Section next;
  
  public void connect(Section other) {
    this.setNext(other);
    other.setPrev(this);
    
    Position otherPos = this.getExitPosition().invTransform(other.getEntry());
    other.getPiece().setPosition(otherPos);
  }
  
  public Section reverse() {
    return new ReverseSection(this);
  }
  
  public Position getPosition() {
    return this.getPiece().getPosition();
  }

  public Position getEntryPosition() {
    return this.getPosition().transform(this.getEntry());
  }

  public Position getExitPosition() {
    return this.getPosition().transform(this.getExit());
  }
  
  public Position mapOffsetToPosition(Position offset) {
    return getPiece().mapOffsetToPosition(this, offset);
  }

  public double getOffsetByLocation(int locationId) {
    return getPiece().getOffsetByLocation(locationId);
  }
  
  @Override
  public String toString() {
    return getPiece().getClass().getSimpleName() + "(" + getPiece().getId() + ")";
  }
}
