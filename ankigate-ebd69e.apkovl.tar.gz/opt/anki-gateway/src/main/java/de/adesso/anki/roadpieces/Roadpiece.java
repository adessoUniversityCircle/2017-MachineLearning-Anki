package de.adesso.anki.roadpieces;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

import de.adesso.anki.roadmap.Position;
import de.adesso.anki.roadmap.Roadmap;
import de.adesso.anki.roadmap.Section;

public abstract class Roadpiece {
  private final static Reflections reflections = new Reflections("de.adesso.anki.roadpieces");
  
  private Position position;
  protected Section section;
  
  private int roadpieceId;
  
  public static Roadpiece createFromId(int roadpieceId) {
    Set<Class<? extends Roadpiece>> roadpieces = reflections.getSubTypesOf(Roadpiece.class);

    for (Class<? extends Roadpiece> roadpiece : roadpieces) {
      try {
        int[] ids = (int[]) roadpiece.getField("ROADPIECE_IDS").get(null);

        if (Arrays.binarySearch(ids, roadpieceId) >= 0) {
          Roadpiece piece = roadpiece.newInstance();
          piece.roadpieceId = roadpieceId;
          return piece;
        }
      } catch (NoSuchFieldException | IllegalAccessException | InstantiationException | ClassCastException e) {
        // just skip the Roadpiece subclass if there is no ROADPIECE_IDS constant
        // or it cannot be instantiated
      }
    }

    return null;
  }
  
  public Position getPosition() {
    return position;
  }
  
  public void setPosition(Position position) {
    this.position = position;
  }
  
  @JsonIgnore
  public List<Section> getSections() {
    return ImmutableList.of(section);
  }
  
  public String getType() {
    return getClass().getSimpleName();
  };
  
  public Section getSectionByLocation(int locationId, boolean reverse)
  {
    return reverse ? section.reverse() : section;
  }
  
  public Position mapOffsetToPosition(Section section, Position offset) {
    return section.getEntry().transform(offset);
  }
  
  
  public static void main(String[] args) {
    
    Roadmap map = new Roadmap();
    
    Roadpiece r0 = Roadpiece.createFromId(40);
    
    Section s0 = r0.getSectionByLocation(0, false);
    Section s1 = s0.reverse();
    
    r0.setPosition(Position.at(0, 0));
    map.setAnchor(s0);
    
    Position travel = Position.at(100, -50);

    s0.mapOffsetToPosition(travel);
    s1.mapOffsetToPosition(travel);
    
    System.out.println(map.toList().toArray());
    
    System.exit(0);
  }

  public int getId() {
    return roadpieceId;
  }

  public double getOffsetByLocation(int locationId) {
    // TODO Auto-generated method stub
    return 0;
  }
}
