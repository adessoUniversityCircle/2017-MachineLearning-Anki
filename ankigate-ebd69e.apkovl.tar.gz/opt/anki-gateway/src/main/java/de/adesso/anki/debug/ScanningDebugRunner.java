package de.adesso.anki.debug;

import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import de.adesso.anki.AnkiConnector;
import de.adesso.anki.RoadmapScanner;
import de.adesso.anki.Vehicle;
import de.adesso.anki.messages.LightsPatternMessage;
import de.adesso.anki.messages.LightsPatternMessage.LightChannel;
import de.adesso.anki.messages.LightsPatternMessage.LightConfig;
import de.adesso.anki.messages.LightsPatternMessage.LightEffect;
import de.adesso.anki.messages.LocalizationPositionUpdateMessage;
import de.adesso.anki.messages.LocalizationTransitionUpdateMessage;
import de.adesso.anki.messages.Message;
import de.adesso.anki.messages.PingRequestMessage;
import de.adesso.anki.messages.SdkModeMessage;
import de.adesso.anki.messages.SetSpeedMessage;
import de.adesso.anki.messages.TurnMessage;
import de.adesso.anki.roadmap.Roadmap;

public class ScanningDebugRunner {
  
  private static RoadmapScanner scanner;
  
  public static void scan() throws IOException {
    anki = new AnkiConnector("localhost");
    
    vehicles = anki.findVehicles();
    
    vehicles.removeIf((Vehicle v) -> v.getAdvertisement().isCharging());
    
    for (Vehicle v : vehicles) {
      v.connect();

      v.sendMessage(new SdkModeMessage());
      scanner = new RoadmapScanner(v);
      scanner.startScanning();
    }
  }
  
  public static void disconnect() {
    vehicles.forEach((Vehicle v) -> v.disconnect());
    anki.close();
  }
  
  public static Roadmap getRoadmap() {
    return scanner != null ? scanner.getRoadmap() : null;
  }
  
  private static AnkiConnector anki;
  private static List<Vehicle> vehicles;
}
