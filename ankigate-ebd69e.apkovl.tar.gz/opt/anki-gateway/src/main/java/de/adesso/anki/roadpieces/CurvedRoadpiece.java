package de.adesso.anki.roadpieces;

import de.adesso.anki.roadmap.Position;
import de.adesso.anki.roadmap.ReverseSection;
import de.adesso.anki.roadmap.Section;

public class CurvedRoadpiece extends Roadpiece {

  public final static int[] ROADPIECE_IDS = { 17, 18, 20, 23, 24, 27 };
  public final static Position ENTRY = Position.at(-280, 0);
  public final static Position EXIT = Position.at(0, -280, 90);
  public final static Position CENTER = Position.at(-280, -280);

  public CurvedRoadpiece() {
    this.section = new Section(this, ENTRY, EXIT);
  }
  
  @Override
  public Position mapOffsetToPosition(Section section, Position offset) {
    double offsetX = offset.getX();
    double offsetY = offset.getY();
    
    double radius = section.getEntry().transform(Position.at(0, offsetY)).distance(CENTER);
    double angleRad = offsetX / radius;
    
    double x, y, angle;
    if (section instanceof ReverseSection) {
      x = radius * Math.cos(angleRad) + CENTER.getX();
      y = radius * Math.sin(angleRad) + CENTER.getY();
      angle = 270 - 180 * angleRad / Math.PI;
    }
    else {
      x = radius * Math.sin(angleRad) + CENTER.getX();
      y = radius * Math.cos(angleRad) + CENTER.getY();
      angle = 180 * angleRad / Math.PI;
    }
        
    return Position.at(x, y, angle);
  }
  
  @Override
  public double getOffsetByLocation(int locationId) {
    if (locationId < 20)
      return 9.0*(locationId/2) - 67.5;
    else
      return 9.0*((locationId-20)/3) + 22.5;
  }
  
  
  public static void main(String[] args) {
    Roadpiece r = Roadpiece.createFromId(17);
    Section s = r.getSectionByLocation(10, true);
    Position p = r.mapOffsetToPosition(s, Position.at(0, 50));
    
    System.exit(0);
  }
}
