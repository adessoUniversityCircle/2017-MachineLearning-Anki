package de.adesso.anki.roadmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import de.adesso.anki.roadpieces.Roadpiece;

public class Roadmap {
  
  private Section anchor;
  private Section current;
  
  public void setAnchor(Section anchor) {
    this.anchor = anchor;
  }
  
  public void addSection(Section section) {
    if (current == null) {
      anchor = current = section;
      anchor.getPiece().setPosition(Position.at(0,0,0));
    }
    else {
      current.connect(section);
      current = section;

      Position currentExit = current.getExitPosition();
      Position anchorEntry = anchor.getEntryPosition();
      if (currentExit.distance(anchorEntry) < 1) {
        current.connect(anchor);
      }
    }
  }
  
  public void add(int roadpieceId, int locationId, boolean reverse) {
    Roadpiece piece = Roadpiece.createFromId(roadpieceId);
    Section section = piece.getSectionByLocation(locationId, reverse);
    
    this.addSection(section);
  }
  
  public List<Roadpiece> toList() {
    if (anchor == null) return Collections.emptyList();
    
    List<Roadpiece> list = new ArrayList<>();
    list.add(anchor.getPiece());
    
    Section iterator = anchor.getNext();
    while (iterator != null && iterator != anchor) {
      if (iterator.getPiece() != null) {
        list.add(iterator.getPiece());
      }
      iterator = iterator.getNext();
    }
    
    return Collections.unmodifiableList(list);
  }
  
  public boolean isComplete() {
    return anchor != null && anchor.getPrev() != null;
  }

  public Roadpiece findRoadpieceById(int roadPieceId) {
    Section iterator = anchor.getNext();
    
    while (iterator != null) {
      if (iterator.getPiece().getId() == roadPieceId)
        return iterator.getPiece();
      
      if (iterator == anchor) return null;
      
      iterator = iterator.getNext();
    }
    
    return null;
  }
  
}
