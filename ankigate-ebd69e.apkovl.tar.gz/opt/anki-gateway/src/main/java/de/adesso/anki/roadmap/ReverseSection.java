package de.adesso.anki.roadmap;

import de.adesso.anki.roadpieces.Roadpiece;

public class ReverseSection extends Section {

  private Section original;
  
  public ReverseSection(Section original) {
    this.original = original;
  }
  
  public Section reverse() {
    return original;
  }

  public Section getPrev() {
    return original.getNext() != null ? original.getNext().reverse() : null;
  }
  
  public void setPrev(Section prev) {
    original.setNext(prev.reverse());
  }

  public Section getNext() {
    return original.getPrev() != null ? original.getPrev().reverse() : null;
  }

  public void setNext(Section next) {
    original.setPrev(next.reverse());
  }

  public Roadpiece getPiece() {
    return original.getPiece();
  }

  public Position getEntry() {
    return original.getExit().reverse();
  }

  public Position getExit() {
    return original.getEntry().reverse();
  }
  
  @Override
  public double getOffsetByLocation(int locationId) {
    return -1 * original.getOffsetByLocation(locationId);
  }
  
  @Override
  public String toString() {
    return original.toString() + " reversed";
  }
  
}
