package de.adesso.anki;

import java.io.IOException;
import java.time.LocalTime;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.google.common.collect.LinkedListMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

import de.adesso.anki.messages.Message;
import de.adesso.anki.messages.PingRequestMessage;

// TODO: Manage connection status and fail gracefully if disconnected

/**
 * Represents a vehicle and allows communicating with it.
 *
 * @author Yannick Eckey <yannick.eckey@adesso.de>
 */
public class Vehicle {
  
  private String address;
  private AdvertisementData advertisement;
  
  private AnkiConnector anki;
  
  private Multimap<Class<? extends Message>, MessageListener> listeners;
  private boolean connected;
  
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public AdvertisementData getAdvertisement() {
    return advertisement;
  }

  public void setAdvertisement(AdvertisementData advertisement) {
    this.advertisement = advertisement;
  }

  public String toString() {
    return advertisement.toString();
  }
  
  public void connect() {
    try {
      int count = 0;
      int maxTries = 20;
      connected = false;
      
      anki.addMessageListener(this, (message) -> { connected = true; fireMessageReceived(message); });
      
      while (!connected) {
        try {
          anki.connect(this);
          
          sendMessage(new PingRequestMessage());
          Thread.sleep(1000);
        } catch (RuntimeException e) {
          if (++count == maxTries)
            throw e;
        }
      }
    } catch (InterruptedException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }
  
  public void disconnect() {
    anki.disconnect(this);
  }
  
  public void sendMessage(Message message) {
    anki.sendMessage(this, message);
    System.out.println(String.format("[%s] > %s: %s", LocalTime.now(), this, message));
  }
  
  @Deprecated
  public void addMessageListener(MessageListener listener) {
    this.addMessageListener(Message.class, listener);
  }
  
  @Deprecated
  public void removeMessageListener(MessageListener listener) {
    this.removeMessageListener(Message.class, listener);
  }
  
  public <T extends Message> void addMessageListener(Class<T> klass, MessageListener<T> listener) {
    this.listeners.put(klass, listener);
  }
  
  public <T extends Message> void removeMessageListener(Class<T> klass, MessageListener<T> listener) {
    this.listeners.remove(klass, listener);
  }
  
  private <T extends Message> void fireMessageReceived(T message) {
    for (MessageListener<T> l : this.listeners.get(Message.class)) {
      l.messageReceived(message);
    }
    if (message.getClass() != Message.class) {
      for (MessageListener<T> l : this.listeners.get(message.getClass())) {
        l.messageReceived(message);
      }
    }
  }
  
  public Vehicle(AnkiConnector anki, String address, String manufacturerData, String localName) {
    try {
      this.anki = new AnkiConnector("localhost", 5000);
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    this.address = address;
    this.advertisement = new AdvertisementData(manufacturerData, localName);
    
    this.listeners = LinkedListMultimap.create();
  }

  public String getColor() {
    return advertisement.getModel().getColor();
  }
}
