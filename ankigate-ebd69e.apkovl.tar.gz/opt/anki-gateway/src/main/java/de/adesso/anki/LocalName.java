package de.adesso.anki;

public class LocalName {
  
}
